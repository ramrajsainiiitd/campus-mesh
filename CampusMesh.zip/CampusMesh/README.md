# Campus Mesh — offline mesh chat for your 100 students

A fully offline group chat that works with **no internet, no SIM data, and no
Wi-Fi router**. It uses your phones' Bluetooth and Wi-Fi Direct radios
directly, and relays messages phone-to-phone so they can travel across your
whole 1 km area even though no single Bluetooth link reaches that far.

## Why this works for your situation

- Bluetooth/BLE realistically reaches ~10–100m (up to ~200m outdoors with
  clear line of sight).
- You said at least one student is always within 100m of another — that's
  exactly what a **mesh network** needs. A message doesn't need a direct
  link from sender to receiver; it hops through whichever phones are in
  between, like a bucket brigade.
- The app uses Google's **Nearby Connections API**, which automatically
  chooses the best available radio (Bluetooth Classic, BLE, or Wi-Fi
  Direct/Hotspot) between any two nearby phones — you don't manage that
  yourself.
- Every message is flooded to all directly-connected peers, each of whom
  re-sends it once (with a hop-limit/TTL and duplicate filter so it doesn't
  loop forever). With 100 phones spread over 1 km, a message typically
  reaches everyone within a few seconds.

## Privacy

- No servers, no accounts, no phone numbers, no internet — the app never
  requests the `INTERNET` permission.
- Messages are encrypted (AES-256-GCM) using a **shared group passphrase**
  that only your 100 students know. Anyone whose phone doesn't have the
  matching passphrase just sees random noise and their app silently
  discards it — so even if a stranger nearby installs the same APK, they
  can't read your chat without the passphrase.
- Set the passphrase once (e.g. share it verbally in your WhatsApp group
  before switching off data) — everyone types the same phrase into the
  "Class group passphrase" field on first launch.

## How to build the APK

You'll need **Android Studio** (free, from developer.android.com) on a
Windows/Mac/Linux computer — building/signing an APK isn't something that
can be done from a phone alone.

1. Open Android Studio → **Open** → select the `CampusMesh` folder.
2. Let Gradle sync (downloads dependencies — this one step needs internet,
   the built app itself never does).
3. Connect an Android phone via USB (enable Developer Options → USB
   debugging), or use **Build → Generate Signed Bundle/APK → APK**.
4. Copy the resulting `app-release.apk` to each student's phone (via USB,
   or share it once over the campus Wi-Fi/hotspot before going offline) and
   install it (enable "Install unknown apps" for the file manager).

## First run on each phone

1. Open the app → enter a display name and the **same group passphrase**
   as everyone else → Start.
2. Grant the Bluetooth/Wi-Fi/Nearby permissions when asked (required — this
   is what lets phones find each other, Android has no way around it).
3. Leave the app open (or in a foreground state) — you'll see "N device(s)
   directly connected" tick up as nearby classmates' phones are found.
4. Type and send — your message appears instantly for you and ripples out
   to everyone else over the mesh.

## Known limitations (be upfront with your students about these)

- **Not background-persistent by default**: Android aggressively kills
  Bluetooth/Wi-Fi scanning for backgrounded apps to save battery. For a
  hackathon/project this is fine; for daily production use you'd want to
  move the mesh logic into a foreground `Service` with a persistent
  notification (I can add this if you want).
- **Throughput and range depend on phone density**: if a large gap opens up
  with nobody in between, messages can't cross it until someone walks
  through the gap. That's inherent to any mesh network, not just this app.
- **Play Services dependency**: Nearby Connections API requires Google Play
  Services to be installed (true for the vast majority of Android phones,
  but not custom ROMs without Google apps).
- **No message history sync**: a phone that was off/out of range doesn't
  retroactively get messages sent while it was gone (store-and-forward
  can be added later — see "Possible next steps" below).

## Possible next steps

- Foreground `Service` so the mesh stays alive while the app is minimized.
- Store-and-forward: cache the last N messages and share them with newly
  (re)connected peers, like a real mesh (similar to how Bridgefy/Briar work).
- Group/channel support (e.g. per-class instead of one big group).
- Read receipts / delivery confirmation per hop.

## Project structure

```
CampusMesh/
├── app/src/main/java/com/campus/mesh/
│   ├── MainActivity.kt      – UI, permissions, lifecycle
│   ├── MeshManager.kt       – Nearby Connections mesh networking + flooding relay
│   ├── ChatMessage.kt       – message model (id, ttl, sender, text)
│   ├── ChatAdapter.kt       – RecyclerView chat bubbles
│   └── SimpleCrypto.kt      – AES-GCM encrypt/decrypt with group passphrase
└── app/src/main/res/        – layouts, drawables, strings
```
