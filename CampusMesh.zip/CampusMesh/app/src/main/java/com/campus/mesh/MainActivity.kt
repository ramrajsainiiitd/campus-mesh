package com.campus.mesh

import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.campus.mesh.databinding.ActivityMainBinding
import java.util.UUID

class MainActivity : AppCompatActivity(), MeshManager.Listener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var meshManager: MeshManager
    private lateinit var adapter: ChatAdapter
    private lateinit var prefs: SharedPreferences

    private lateinit var userId: String
    private var nickname: String = ""
    private var passphrase: String = ""

    private val requiredPermissions: Array<String>
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                android.Manifest.permission.BLUETOOTH_ADVERTISE,
                android.Manifest.permission.BLUETOOTH_CONNECT,
                android.Manifest.permission.BLUETOOTH_SCAN,
                android.Manifest.permission.NEARBY_WIFI_DEVICES
            )
        } else {
            arrayOf(
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            )
        }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            meshManager.start()
        } else {
            binding.textStatus.text = "Permissions denied - mesh chat needs Bluetooth/Wi-Fi/nearby permissions to work."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences("campus_mesh_prefs", MODE_PRIVATE)
        userId = prefs.getString("user_id", null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString("user_id", it).apply()
        }
        nickname = prefs.getString("nickname", "") ?: ""
        passphrase = prefs.getString("passphrase", "") ?: ""

        adapter = ChatAdapter(mutableListOf(), userId)
        binding.recyclerMessages.layoutManager = LinearLayoutManager(this)
        binding.recyclerMessages.adapter = adapter

        binding.buttonSend.setOnClickListener {
            val text = binding.editMessage.text.toString().trim()
            if (text.isNotEmpty()) {
                meshManager.sendMessage(text)
                binding.editMessage.text.clear()
            }
        }

        binding.buttonSettings.setOnClickListener { showSetupDialog(forceShow = true) }

        meshManager = MeshManager(applicationContext, userId, nickname, passphrase, this)

        if (nickname.isBlank() || passphrase.isBlank()) {
            showSetupDialog(forceShow = false)
        } else {
            requestPermissionsAndStart()
        }
    }

    /** Nickname = shown to others. Passphrase = shared group secret, must match on every phone. */
    private fun showSetupDialog(forceShow: Boolean) {
        val view = layoutInflater.inflate(R.layout.dialog_setup, null)
        val nameField = view.findViewById<android.widget.EditText>(R.id.editNickname)
        val passField = view.findViewById<android.widget.EditText>(R.id.editPassphrase)
        nameField.setText(nickname)
        passField.setText(passphrase)

        AlertDialog.Builder(this)
            .setTitle("Join Campus Mesh")
            .setMessage("Enter your name and the group passphrase your class agreed on. Everyone must use the SAME passphrase to see each other's messages.")
            .setView(view)
            .setCancelable(!forceShow && nickname.isNotBlank() && passphrase.isNotBlank())
            .setPositiveButton("Start") { _, _ ->
                nickname = nameField.text.toString().ifBlank { "Student${(1000..9999).random()}" }
                passphrase = passField.text.toString().ifBlank { "default-passphrase" }
                prefs.edit().putString("nickname", nickname).putString("passphrase", passphrase).apply()
                meshManager.updateNickname(nickname)
                meshManager.updatePassphrase(passphrase)
                requestPermissionsAndStart()
            }
            .show()
    }

    private fun requestPermissionsAndStart() {
        val missing = requiredPermissions.filter {
            checkSelfPermission(it) != android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            meshManager.start()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        meshManager.stop()
    }

    // ---- MeshManager.Listener callbacks (may arrive on background thread) ----

    override fun onMessageReceived(message: ChatMessage) {
        runOnUiThread {
            adapter.addMessage(message)
            binding.recyclerMessages.scrollToPosition(adapter.itemCount - 1)
        }
    }

    override fun onPeerCountChanged(count: Int) {
        runOnUiThread {
            binding.textPeerCount.text = "$count device(s) directly connected"
        }
    }

    override fun onStatusUpdate(text: String) {
        runOnUiThread {
            binding.textStatus.text = text
        }
    }
}
