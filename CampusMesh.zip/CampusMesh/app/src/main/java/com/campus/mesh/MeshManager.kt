package com.campus.mesh

import android.content.Context
import android.util.Log
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONObject
import java.util.Collections
import java.util.UUID

/**
 * Handles the actual offline mesh network.
 *
 * Uses Google's Nearby Connections API in P2P_CLUSTER mode, which
 * transparently negotiates Bluetooth Classic, BLE, and Wi-Fi
 * Direct/Hotspot between pairs of nearby phones - no internet,
 * no SIM, no router required.
 *
 * Multi-hop mesh behaviour: every message is flooded to all directly
 * connected peers. Each peer that receives a *new* message (checked via
 * message id) displays it locally AND re-broadcasts it to its own peers
 * with ttl-1. This is how a message from Student A can reach Student Z
 * 900m away even though A and Z were never in direct radio range -
 * it hops through whoever is in between.
 */
class MeshManager(
    private val context: Context,
    private val myUserId: String,
    private var myNickname: String,
    private var groupPassphrase: String,
    private val listener: Listener
) {
    interface Listener {
        fun onMessageReceived(message: ChatMessage)
        fun onPeerCountChanged(count: Int)
        fun onStatusUpdate(text: String)
    }

    companion object {
        private const val TAG = "MeshManager"
        // All students must share this exact string so their phones find
        // each other and ignore unrelated Nearby Connections traffic.
        private const val SERVICE_ID = "com.campus.mesh.SERVICE"
        private val STRATEGY = Strategy.P2P_CLUSTER
        private const val MAX_SEEN_IDS = 500
    }

    private val connectionsClient = Nearby.getConnectionsClient(context)

    // endpointId -> connected & ready to send
    private val connectedEndpoints = Collections.synchronizedSet(mutableSetOf<String>())

    // De-dupe cache so flooded messages aren't shown/relayed twice.
    private val seenMessageIds = Collections.synchronizedList(mutableListOf<String>())

    fun updateNickname(nickname: String) { myNickname = nickname }
    fun updatePassphrase(passphrase: String) { groupPassphrase = passphrase }

    fun start() {
        startAdvertising()
        startDiscovery()
    }

    fun stop() {
        connectionsClient.stopAdvertising()
        connectionsClient.stopDiscovery()
        connectionsClient.stopAllEndpoints()
        connectedEndpoints.clear()
        listener.onPeerCountChanged(0)
    }

    private fun startAdvertising() {
        val options = com.google.android.gms.nearby.connection.AdvertisingOptions.Builder()
            .setStrategy(STRATEGY)
            .build()

        connectionsClient.startAdvertising(
            myNickname, SERVICE_ID, connectionLifecycleCallback, options
        ).addOnSuccessListener {
            listener.onStatusUpdate("Advertising as \"$myNickname\"")
        }.addOnFailureListener { e ->
            Log.e(TAG, "startAdvertising failed", e)
            listener.onStatusUpdate("Advertising failed: ${e.message}")
        }
    }

    private fun startDiscovery() {
        val options = com.google.android.gms.nearby.connection.DiscoveryOptions.Builder()
            .setStrategy(STRATEGY)
            .build()

        connectionsClient.startDiscovery(
            SERVICE_ID, endpointDiscoveryCallback, options
        ).addOnFailureListener { e ->
            Log.e(TAG, "startDiscovery failed", e)
            listener.onStatusUpdate("Discovery failed: ${e.message}")
        }
    }

    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            // Found a nearby phone running the same app - request connection.
            connectionsClient.requestConnection(myNickname, endpointId, connectionLifecycleCallback)
        }

        override fun onEndpointLost(endpointId: String) {
            connectedEndpoints.remove(endpointId)
            listener.onPeerCountChanged(connectedEndpoints.size)
        }
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            // Auto-accept: this is a closed group app (passphrase gates the
            // content anyway), so we don't make 100 students manually
            // confirm every pairing code.
            connectionsClient.acceptConnection(endpointId, payloadCallback)
        }

        override fun onConnectionResult(endpointId: String, resolution: ConnectionResolution) {
            if (resolution.status.statusCode == ConnectionsStatusCodes.STATUS_OK) {
                connectedEndpoints.add(endpointId)
                listener.onPeerCountChanged(connectedEndpoints.size)
                listener.onStatusUpdate("Connected to a peer (${connectedEndpoints.size} nearby)")
            }
        }

        override fun onDisconnected(endpointId: String) {
            connectedEndpoints.remove(endpointId)
            listener.onPeerCountChanged(connectedEndpoints.size)
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return
            val bytes = payload.asBytes() ?: return
            handleIncomingBytes(bytes, receivedFromEndpoint = endpointId)
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            // Not needed for small text payloads; here for completeness.
        }
    }

    private fun handleIncomingBytes(bytes: ByteArray, receivedFromEndpoint: String) {
        val encoded = String(bytes, Charsets.UTF_8)
        val plain = SimpleCrypto.decrypt(encoded, groupPassphrase) ?: return // wrong passphrase group, ignore
        val message = try {
            ChatMessage.fromJson(JSONObject(plain))
        } catch (e: Exception) {
            return
        }

        if (seenMessageIds.contains(message.id)) return // already handled this one
        recordSeen(message.id)

        listener.onMessageReceived(message)

        // Relay onward (mesh flood) if it still has hops left.
        if (message.ttl > 1) {
            message.ttl -= 1
            broadcastRaw(message, excludeEndpoint = receivedFromEndpoint)
        }
    }

    private fun recordSeen(id: String) {
        seenMessageIds.add(id)
        if (seenMessageIds.size > MAX_SEEN_IDS) {
            seenMessageIds.removeAt(0)
        }
    }

    /** Called by the UI when the local user types a message. */
    fun sendMessage(text: String) {
        val message = ChatMessage(
            senderId = myUserId,
            senderName = myNickname,
            text = text
        )
        recordSeen(message.id)
        listener.onMessageReceived(message) // show it locally immediately
        broadcastRaw(message, excludeEndpoint = null)
    }

    private fun broadcastRaw(message: ChatMessage, excludeEndpoint: String?) {
        val encrypted = SimpleCrypto.encrypt(message.toJson().toString(), groupPassphrase)
        val payload = Payload.fromBytes(encrypted.toByteArray(Charsets.UTF_8))
        val targets = connectedEndpoints.filter { it != excludeEndpoint }
        if (targets.isNotEmpty()) {
            connectionsClient.sendPayload(targets, payload)
        }
    }
}
