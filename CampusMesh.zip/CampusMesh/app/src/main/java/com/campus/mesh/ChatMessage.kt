package com.campus.mesh

import org.json.JSONObject
import java.util.UUID

/**
 * A single chat message that gets flooded across the mesh.
 *
 * id       - unique id, used to de-duplicate so the same message isn't
 *            shown/relayed twice when it arrives via multiple hops.
 * ttl      - hop budget. Decremented on every relay; message stops
 *            spreading once it hits 0. Prevents infinite flooding.
 * senderId - stable per-install id so you know who sent it even after
 *            multiple hops.
 */
data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val senderId: String,
    val senderName: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    var ttl: Int = 6
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("senderId", senderId)
        put("senderName", senderName)
        put("text", text)
        put("timestamp", timestamp)
        put("ttl", ttl)
    }

    companion object {
        fun fromJson(json: JSONObject): ChatMessage = ChatMessage(
            id = json.getString("id"),
            senderId = json.getString("senderId"),
            senderName = json.getString("senderName"),
            text = json.getString("text"),
            timestamp = json.getLong("timestamp"),
            ttl = json.getInt("ttl")
        )
    }
}
