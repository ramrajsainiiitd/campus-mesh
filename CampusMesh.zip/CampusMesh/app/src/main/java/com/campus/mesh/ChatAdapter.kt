package com.campus.mesh

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Locale

class ChatAdapter(
    private val messages: MutableList<ChatMessage>,
    private val myUserId: String
) : RecyclerView.Adapter<ChatAdapter.VH>() {

    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val sender: TextView = view.findViewById(R.id.textSender)
        val body: TextView = view.findViewById(R.id.textBody)
        val time: TextView = view.findViewById(R.id.textTime)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val msg = messages[position]
        val isMine = msg.senderId == myUserId
        holder.sender.text = if (isMine) "You" else msg.senderName
        holder.body.text = msg.text
        holder.time.text = timeFormat.format(msg.timestamp)
        holder.itemView.setBackgroundResource(
            if (isMine) R.drawable.bg_bubble_sent else R.drawable.bg_bubble_received
        )
    }

    override fun getItemCount(): Int = messages.size

    fun addMessage(message: ChatMessage) {
        messages.add(message)
        notifyItemInserted(messages.size - 1)
    }
}
